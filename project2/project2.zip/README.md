### Files used

1. The following file contains main code:
    - bikeshare.py
2. Needed files for code investigating
    - chicago.csv
    - new_york_city.csv
    - washington.csv

### References

-   If I have doubts about the errors occured while running the code I used: www.stackoverflow.com, www.chatgpt.com
-   Also for gotten code, syntax I was using www.w3schools.com for basic knowleadge syntax, it was better for searching
